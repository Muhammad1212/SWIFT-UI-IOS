//
//  Assign4App.swift
//  Assign4
//
//  Created by user229294 on 11/5/22.
//Muhammad Naeem 

import SwiftUI

@main
struct Assign4App: App {
    var body: some Scene {
        WindowGroup {
            PresidentListView()
        }
    }
}

//Citations
//Mr Kurt McMahon
//Apple developr website
