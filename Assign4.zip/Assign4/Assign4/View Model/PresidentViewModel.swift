//
//  PresidentViewModel.swift
//  Assign4
//
//  Created by user229294 on 11/5/22.
//

import Foundation


struct PresidentViewModel {
    var president: PName
    
    var Name: String {
        return president.Name
    }
    
    var Number: Int {
        return president.Number
    }
    
    var StartDate: String {
        return president.StartDate
    }
    
    var EndDate: String {
        return president.EndDate
    }
    
    var Nickname: String {
        return president.Nickname
    }
    
    var politicalparty: String {
        return president.politicalparty
    }
    

    
    
    static var `default`: PresidentViewModel {
        let president = PName (Name: "president.Name", Number: 1, StartDate: "president.StartDate", EndDate: "president.EndDate", Nickname: "president.Nickname", politicalparty: "president.politialparty")
        return PresidentViewModel(president: president)
    }
}

