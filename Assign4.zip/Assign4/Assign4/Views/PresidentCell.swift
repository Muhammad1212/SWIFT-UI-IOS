//
//  PresidentCell.swift
//  Assign4
//
//  Created by user229294 on 11/5/22.
//

import SwiftUI

struct PresidentCell: View {
    
    var president: PresidentViewModel
    
    var body: some View {
        HStack {
        
            VStack(alignment: .leading) {
                Text(president.Name)
                    .font(.headline)
                    .fontWeight(.heavy)
                Text(president.politicalparty)
                    .font(.subheadline)
            }
        }
    }
}

struct PresidentCell_Previews: PreviewProvider {
    static var previews: some View {
        PresidentCell( president: PresidentViewModel.default)
            .previewLayout(.sizeThatFits)
    }
        
}
