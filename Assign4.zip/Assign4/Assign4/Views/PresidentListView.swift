//
//  PresidentListView.swift
//  Assign4
//
//  Created by user229294 on 11/5/22.
//



import SwiftUI

struct PresidentListView: View {
    
    @StateObject private var presidentListVM = PresidentListViewModel()
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(presidentListVM.presidents, id: \.Name) {
                    presidentVM in
                    NavigationLink(destination: PresidentDetailView(president: presidentVM)) {
                        PresidentCell(president: presidentVM)
                    }
                }
            }
            .listStyle(.plain)
            .navigationTitle("Presidents")
            .navigationBarTitleDisplayMode(.inline)
        }
        .onAppear {
            presidentListVM.loadPropertyList()
        }
    }
}

struct PresidentListView_Previews: PreviewProvider {
    static var previews: some View {
        PresidentListView()
    }
}
