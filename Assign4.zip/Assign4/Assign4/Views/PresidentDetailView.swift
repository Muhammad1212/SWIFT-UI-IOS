//
//  PresidentDetailView.swift
//  Assign4
//
//  Created by user229294 on 11/5/22.
//

import SwiftUI
import Foundation

    
struct PresidentDetailView: View {
    
    var president: PresidentViewModel

    var body: some View {
        VStack(spacing: 16) {
            Text(president.Name)
                .font(.largeTitle)
                .fontWeight(.heavy)
                .multilineTextAlignment(.center)
           
          

    let str1 = String(president.Number)


                Text("#\(str1)st")
                .fontWeight(.semibold)
            Text("President of the United States")
              .fontWeight(.semibold)
            
            Text("(\(president.StartDate)")
                .italic()
            Text(",\(president.EndDate))")
                .italic()
            
            Image("seal")
                .resizable()
                .scaledToFit()
                .cornerRadius(16)
                .padding(.horizontal)
            
            
            Text("Nickname")
                .fontWeight(.semibold)
            
            Text(president.Nickname)
                
            Text("Political Party")
                .fontWeight(.semibold);
            
            Text(president.politicalparty)
            
            
           // Spacer()
        }
    
    }
}

struct PresidentDetailView_Previews: PreviewProvider {
    static var previews: some View {
        PresidentDetailView(president:  PresidentViewModel.default)
    }
}
