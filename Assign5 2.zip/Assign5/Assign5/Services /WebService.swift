//
//  Webservice.swift
//  Assign5
//
//  Created by user229294 on 11/23/22.
//

import Foundation


class WebService { //getting proper notation for decoding JSOn file
    
    func fetchPresidents(url: URL?) async throws -> [PName] {
        
        guard let url = url else {
            return []
        }
        
        let (data, _) = try await URLSession.shared.data(from: url)
        
        let presidents = try? JSONDecoder().decode([PName].self,from: data)
        
        return presidents ?? []
    }
}
