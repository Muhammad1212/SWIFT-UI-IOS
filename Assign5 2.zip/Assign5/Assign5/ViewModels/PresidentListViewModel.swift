//
//  PresidentListViewModel.swift
//  Assign5
//
//  Created by user229294 on 11/23/22.
//

import Foundation

class PresidentListViewModel: ObservableObject {
    
    @Published var presidents: [PresidentViewModel] = []
    
    func getPresidents()  async{
        
        
        do {
            var presidents = try await
            WebService().fetchPresidents(url: Constants.Urls.presidentsUrl)
            //fetching URL for documentation
            
            presidents.sort {
                $0.Number < $1.Number
            }
            
            self.presidents =
               presidents
                .map(PresidentViewModel.init)
        } catch {
            print(error)        }
    }
    
    
}
