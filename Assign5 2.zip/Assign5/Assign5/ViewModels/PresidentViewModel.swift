//
//  PresidentViewModel.swift
//  Assign5
//
//  Created by user229294 on 11/23/22.
//

import Foundation

struct PresidentViewModel {  //varaiable declaration for each possibility
    var president: PName
    
    
    var Name: String {
        return president.Name
    }
    
    var Number: Int {
        return president.Number
    }
    
    var StartDate: String {
        return president.StartDate
    }
    
    var EndDate: String {
        return president.EndDate
    }
    
    var Nickname: String {
        return president.Nickname
    }
    
    var politicalparty: String {
        return president.politicalparty
    }
    

    var url: String {
        return president.url
    }
    
    static var `default`: PresidentViewModel {
        let president = PName (Name: "president.Name", Number: 1, StartDate: "president.StartDate", EndDate: "president.EndDate", Nickname: "president.Nickname", politicalparty: "president.politialparty", url: " https://www.potus.com/wp-content/uploads/07_andrew_jackson_1_gallery.jpg")
        return PresidentViewModel(president: president)
    }
}
