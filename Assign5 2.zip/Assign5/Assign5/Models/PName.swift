//
//  PName.swift
//  Assign5
//
//  Created by user229294 on 11/23/22.
//

import Foundation
//declaring struct for each party

struct PName: Decodable {
    var Name: String
    var Number: Int
    var StartDate : String
    var EndDate : String
    var Nickname : String
    var politicalparty : String
    var url = ""
    
    private enum CodingKeys: String, CodingKey {
        case Name = "Name"
        case Number = "Number"
        case StartDate = "Start Date"
        case EndDate = "End Date"
        case Nickname = "Nickname"
        case politicalparty = "Political Party"
        case url = "URL"
    }
}
