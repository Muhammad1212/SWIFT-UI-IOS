//
//  Constants.swift
//  Assign5
//
//  Created by user229294 on 11/23/22.
//

import Foundation


struct Constants {
    
    struct Urls {
        static let presidentsUrl: URL? = URL(string: "https://faculty.cs.niu.edu/~mcmahon/CS321/presidents.json") //URL for decoding presidents list jason
    }
}
