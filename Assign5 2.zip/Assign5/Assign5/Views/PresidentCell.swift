//
//  PresidentCell.swift
//  Assign5
//
//  Created by user229294 on 11/23/22.
//


import SwiftUI

struct PresidentCell: View {  //presdient cell for each president inforamtion
    
    var president: PresidentViewModel
    
    var body: some View {
        HStack {
            
            AsyncImage(url: URL(string: president.url)) { image in
                image.resizable()
                    .cornerRadius(6)
            } placeholder: {
                ProgressView()
            }
            .frame(width: 50, height: 50)
            
           
            VStack(alignment: .leading) {
                Text(president.Name)
                    .font(.headline)
                    .fontWeight(.heavy)
                Text(president.politicalparty)
                    .font(.subheadline)
            }
        }
    }
}

struct PresidentCell_Previews: PreviewProvider {
    static var previews: some View {
        PresidentCell( president: PresidentViewModel.default)
            .previewLayout(.sizeThatFits)
    }
        
}
