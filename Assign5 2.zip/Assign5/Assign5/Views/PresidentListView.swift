//
//  PresidentListView.swift
//  Assign5
//
//  Created by user229294 on 11/23/22.
//


import SwiftUI

struct PresidentListView: View {  //view for president list in order
    
    @StateObject private var presidentListVM = PresidentListViewModel()
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(presidentListVM.presidents, id: \.Name) {
                    presidentVM in
                    NavigationLink(destination: PresidentDetailView(president: presidentVM)) {
                        PresidentCell(president: presidentVM)
                    }
                }
            }
            .listStyle(.plain)
            .navigationTitle("Presidents")
            .navigationBarTitleDisplayMode(.inline)
        }
        .task {
            await presidentListVM.getPresidents()        }
    }
}

struct PresidentListView_Previews: PreviewProvider {
    static var previews: some View {
        PresidentListView()
    }
}
