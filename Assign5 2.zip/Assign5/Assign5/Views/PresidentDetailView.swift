//
//  PresidentDetailView.swift
//  Assign5
//
//  Created by user229294 on 11/23/22.
//


import SwiftUI


    
struct PresidentDetailView: View {   //president detail view each term year and name etc
    
    var president: PresidentViewModel

    var body: some View {
        VStack(spacing: 16) {
            Text(president.Name)
                .font(.largeTitle)
                .fontWeight(.heavy)
                .multilineTextAlignment(.center)
           
          

    let str1 = String(president.Number)


                Text("#\(str1)st")
                .fontWeight(.semibold)
            Text("President of the United States")
              .fontWeight(.semibold)
            
            Text("(\(president.StartDate)")
                .italic()
            Text(",\(president.EndDate))")
                .italic()
            
            AsyncImage(url: URL(string: president.url)) { image in
                image.resizable()
                    .scaledToFit()
                    .cornerRadius(16)
            } placeholder: {
                ProgressView()
                
            }
            .padding(.horizontal)
            
            Text("Nickname")
                .fontWeight(.semibold)
            
            Text(president.Nickname)
                
            Text("Political Party")
                .fontWeight(.semibold);
            
            Text(president.politicalparty)
            
            //Spacer()
        }
    
    }
}

struct PresidentDetailView_Previews: PreviewProvider {
    static var previews: some View {
        PresidentDetailView(president:  PresidentViewModel.default)
    }
}
