//
//  Assign5App.swift
//  Assign5
//
//  Created by user229294 on 11/23/22.
//

import SwiftUI
//app for each group and listview
@main
struct Assign5App: App {
    var body: some Scene {
        WindowGroup {
            PresidentListView()
        }
    }
}
