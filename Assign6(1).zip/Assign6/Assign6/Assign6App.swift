//
//  Assign6App.swift
//  Assign6
//
//  Created by user229294 on 11/29/22.
//

import SwiftUI

@main
struct Assign6App: App {

    let persistenceController = PersistenceController.shared
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}

//Citaions
//Mr Kurt McMahon
//Apple developer website
//Stack Overflow
