//
//  ModifyBookView.swift
//  Assign6
//
//  Created by user229294 on 11/29/22.
//

import Foundation

import SwiftUI
import PhotosUI

struct ModifyBookView: View {   //TO edit the album overall
    
    @Environment(\.managedObjectContext) var dbContext
    @Environment(\.dismiss) var dismiss
    
    @State private var inputTitle = ""
    @State private var inputYear = ""
    
    @State private var selectedAuthor: Author? = nil
    @State var selectedItem: PhotosPickerItem? = nil
    @State private var selectedImageData: Data? = nil
    
    @State private var valuesLoaded = false
    
    let book: Book?
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                HStack {
                    Text("Title:")
                    TextField("Insert title", text: $inputTitle)
                        .textFieldStyle(.roundedBorder)
                }
                
                HStack {
                    Text("Year:")
                    TextField("Insert year", text: $inputYear)
                        .textFieldStyle(.roundedBorder)
                }
                
                HStack {
                    Text("Artist:")
                    VStack(alignment: .leading, spacing: 8) {
                        Text(selectedAuthor?.name ?? "Undefined")
                            .foregroundColor(selectedAuthor != nil ? Color.black : Color.gray)
                        NavigationLink(destination: AuthorsListView(selected: $selectedAuthor), label : {
                            Text("Select Artist")
                        })
                    }
                }
                .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)

                PhotosPicker(selection: $selectedItem, matching: .images, photoLibrary: .shared()) {
                    HStack {
                        Image(systemName: "photo")
                            .font(.system(size: 20))
                        
                        Text("Photo Library")
                            .font(.headline)
                    }
                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: 50)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(20)
                    .padding(.horizontal)
                }
                .onChange(of: selectedItem) { newItem in
                    Task {
                        if let data = try? await newItem?.loadTransferable(type: Data.self) {
                            selectedImageData = data
                        }
                    }
                }
                
                if let selectedImageData, let uiImage = UIImage(data: selectedImageData) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFit()
                        .padding()
                } else {
                    Image("nopicture")
                        .resizable()
                        .scaledToFit()
                        .padding()
                }
                
                Spacer()
            }
            .padding()
            .navigationTitle("Modify Album")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        let newTitle = inputTitle.trimmingCharacters(in: .whitespaces)
                        let year = Int32(inputYear)
                        if !newTitle.isEmpty && year != nil {
                            Task(priority: .high) {
                                await storeBook(title: newTitle, year: year!)
                            }
                        }
                        
                    }
                }
            }
        }
        .onAppear {
            if !valuesLoaded {
                selectedAuthor = book?.author
                inputTitle = book?.title ?? ""
                inputYear = book?.showYear ?? ""
                selectedImageData = book?.cover
                valuesLoaded = true
            }
        }
    }
    
    func storeBook(title: String, year: Int32) async {
        await dbContext.perform {
            book?.title = title
            book?.year = year
            book?.author = selectedAuthor
            
            if selectedImageData != nil {
                book?.cover = selectedImageData
            } else {
                book?.cover = nil
            }
            
            do {
                try dbContext.save()
                dismiss()
            } catch {
                print(error)
            }
        }
    }
}

struct ModifyBookView_Previews: PreviewProvider {
    static var previews: some View {
        ModifyBookView(book: nil)
            .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
