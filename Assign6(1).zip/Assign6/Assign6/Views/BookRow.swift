//
//  BookRow.swift
//  Assign6
//
//  Created by user229294 on 11/29/22.
//

import SwiftUI

struct BookRow: View {

    let book: Book           //declaring Album book for each row display

    var body: some View {
        
        HStack(alignment: .top) {
            Image(uiImage: book.showCover)
                .resizable()
                .scaledToFit()
                .frame(width: 80, height: 100)
                .cornerRadius(10)
            
            VStack(alignment: .leading) {
                Text(book.showTitle)
                    .bold()
                Text(book.showAuthor)
                    .foregroundColor((book.author != nil) ? .black : .gray)
                
                Text(book.showYear)
                    .font(.caption)
                
            }
            .padding(.top, 5)
            
            Spacer()
        }
    }
}

struct BookRow_Previews: PreviewProvider {
    
    static let viewContext = PersistenceController.preview.container.viewContext
    
    static var book: Book {
        let book = Book(context: viewContext)
        book.title = "Some Album"
        book.author = nil
        book.year = 2022
        book.cover = nil
        
        return book
    }
    
    static var previews: some View {
        BookRow(book: book)
            .previewLayout(.sizeThatFits)
    }
}
