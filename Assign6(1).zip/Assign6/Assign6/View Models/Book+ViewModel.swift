//
//  Book+VIewModel.swift
//  Assign6
//
//  Created by user229294 on 11/29/22.
//


import Foundation
import SwiftUI

extension Book {                     // struct defifnng each variable year of the Album entitled
    var showTitle: String {
        return title ?? "Undefined"
    }
    
    var showYear: String {
        return String(year)
    }
    
    var showAuthor: String {
        return author?.name ?? "Undefined"
    }
    
    var showCover: UIImage {
        if let data = cover, let image = UIImage(data: data) {
            return image
        } else {
            return UIImage(named: "nopicture")!
        }
    }
}
