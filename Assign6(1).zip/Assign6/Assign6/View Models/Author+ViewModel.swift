//
//  Author+ViewModel.swift
//  Assign6
//
//  Created by user229294 on 11/29/22.
//

import Foundation


extension Author {                         //Album artist declaration
    
    var showName: String {
        return name ?? "Undefined"
    }
}
